var searchData=
[
  ['add_5frecord',['add_record',['../main_8cpp.html#a43124ce79146d45230a5d96e6da92882',1,'main.cpp']]]
];
