var searchData=
[
  ['add_5frecord',['add_record',['../main_8cpp.html#a43124ce79146d45230a5d96e6da92882',1,'main.cpp']]],
  ['additions',['Additions',['../namespace_additions.html',1,'']]],
  ['additions_2ecpp',['Additions.cpp',['../_additions_8cpp.html',1,'']]],
  ['additions_2eh',['Additions.h',['../_additions_8h.html',1,'']]]
];
