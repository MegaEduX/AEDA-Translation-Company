var searchData=
[
  ['order_5ftranslation',['order_translation',['../main_8cpp.html#a531d23ea6ea2ab07c4b928afdbe779ad',1,'main.cpp']]]
];
