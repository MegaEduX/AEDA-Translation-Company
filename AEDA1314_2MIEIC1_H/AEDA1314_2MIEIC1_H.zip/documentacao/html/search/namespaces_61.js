var searchData=
[
  ['additions',['Additions',['../namespace_additions.html',1,'']]]
];
