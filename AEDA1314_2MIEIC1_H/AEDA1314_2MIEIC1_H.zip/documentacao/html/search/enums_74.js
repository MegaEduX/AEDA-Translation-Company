var searchData=
[
  ['tipo_5fjornal',['tipo_jornal',['../_texto_noticioso_8h.html#adbee2daefeb8a5b2ec0e0c0b353390d5',1,'TextoNoticioso.h']]]
];
