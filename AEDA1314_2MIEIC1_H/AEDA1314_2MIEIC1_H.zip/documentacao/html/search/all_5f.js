var searchData=
[
  ['_5fgetch',['_getch',['../_additions_8cpp.html#a27d6eaddec69251ee448adf3d7260055',1,'_getch():&#160;Additions.cpp'],['../_additions_8h.html#a27d6eaddec69251ee448adf3d7260055',1,'_getch():&#160;Additions.cpp']]]
];
