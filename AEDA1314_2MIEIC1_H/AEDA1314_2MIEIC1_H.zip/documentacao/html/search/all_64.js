var searchData=
[
  ['databasemanager',['DatabaseManager',['../class_database_manager.html',1,'DatabaseManager'],['../class_database_manager.html#a24e3c3701ce01fdac96cc170b334aeba',1,'DatabaseManager::DatabaseManager()']]],
  ['databasemanager_2ecpp',['DatabaseManager.cpp',['../_database_manager_8cpp.html',1,'']]],
  ['databasemanager_2eh',['DatabaseManager.h',['../_database_manager_8h.html',1,'']]],
  ['days_5fto_5fseconds',['days_to_seconds',['../_tradutor_8cpp.html#a0442eefd0d507ff91236f184952f5dfa',1,'Tradutor.cpp']]],
  ['delete_5frecord',['delete_record',['../class_database_manager.html#aedc255310da21463f3297f3333898605',1,'DatabaseManager::delete_record(Texto *texto)'],['../class_database_manager.html#a861c8ab275b7d9e100ebb71889578c40',1,'DatabaseManager::delete_record(Tradutor *tradutor)'],['../class_database_manager.html#aa78e5396d0be88098a97703f31fb72ec',1,'DatabaseManager::delete_record(Encomenda *encomenda)']]],
  ['delete_5frecord_5fstep3',['delete_record_step3',['../main_8cpp.html#a900da0c894ff2093f906c69bc0445b31',1,'main.cpp']]],
  ['delete_5frecord_5fwild',['delete_record_wild',['../_database_manager_8cpp.html#ad310b004d92e4d009daa379555ec5810',1,'DatabaseManager.cpp']]],
  ['display_5finfo',['display_info',['../main_8cpp.html#a12813f39b7f720b1cd021aa125df655e',1,'display_info(Tradutor *trad):&#160;main.cpp'],['../main_8cpp.html#a6cbdcfe2366876365517a45b20671c84',1,'display_info(Encomenda *enc):&#160;main.cpp'],['../main_8cpp.html#aa1cee08b518537a6206e2bef0150b627',1,'display_info(Texto *txt):&#160;main.cpp']]]
];
