var searchData=
[
  ['checkforonlynumeric',['checkForOnlyNumeric',['../namespace_additions.html#a5b3d2c5561dcb114fbd92abc7acadc4d',1,'Additions']]],
  ['clearconsole',['clearConsole',['../namespace_additions.html#af13c3c94d99ca27753ac564159b625d3',1,'Additions']]],
  ['complexidade',['complexidade',['../class_texto.html#a9b397139df00ed907e1e6a1c29e2429b',1,'Texto::complexidade()'],['../class_texto_literario.html#a286c1693b71a45d4d577dcd15871892c',1,'TextoLiterario::complexidade()'],['../class_texto_noticioso.html#a1db491d92e2a467d258f0f470f994981',1,'TextoNoticioso::complexidade()'],['../class_texto_tecnico.html#aeeeff7367e226e4fc0f0d4cdb692e85d',1,'TextoTecnico::complexidade()']]],
  ['create_5fupdate_5frecord',['create_update_record',['../class_database_manager.html#a10e0b6e056bcc0b669e272b839ae92fe',1,'DatabaseManager::create_update_record(Texto *texto)'],['../class_database_manager.html#a587389f45912fee630df72658a4d09b0',1,'DatabaseManager::create_update_record(Tradutor *tradutor)'],['../class_database_manager.html#a10fd54af873e6902a3a6ee45f71eb42c',1,'DatabaseManager::create_update_record(Encomenda *encomenda)']]],
  ['currenttimestamp',['currentTimestamp',['../namespace_additions.html#a58d17107bba40cd0b819f7e595a4dd4e',1,'Additions']]],
  ['custotraducao',['custoTraducao',['../class_tradutor.html#ab55718903fb3e7cc5c1b21b87d64393a',1,'Tradutor']]]
];
