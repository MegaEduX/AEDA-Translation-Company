var searchData=
[
  ['tipo_5fjornal_5fdiario',['tipo_jornal_diario',['../_texto_noticioso_8h.html#adbee2daefeb8a5b2ec0e0c0b353390d5ac24612edaf40d3e32051ffd6b9d5e66f',1,'TextoNoticioso.h']]],
  ['tipo_5fjornal_5fsemanario',['tipo_jornal_semanario',['../_texto_noticioso_8h.html#adbee2daefeb8a5b2ec0e0c0b353390d5af48430c9000475e4d945b3e7e6dba661',1,'TextoNoticioso.h']]]
];
