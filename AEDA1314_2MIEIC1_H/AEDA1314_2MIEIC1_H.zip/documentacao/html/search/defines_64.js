var searchData=
[
  ['days_5fto_5fseconds',['days_to_seconds',['../_tradutor_8cpp.html#a0442eefd0d507ff91236f184952f5dfa',1,'Tradutor.cpp']]],
  ['delete_5frecord_5fwild',['delete_record_wild',['../_database_manager_8cpp.html#ad310b004d92e4d009daa379555ec5810',1,'DatabaseManager.cpp']]]
];
