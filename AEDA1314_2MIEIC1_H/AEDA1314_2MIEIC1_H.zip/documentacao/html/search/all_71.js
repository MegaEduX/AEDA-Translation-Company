var searchData=
[
  ['query_5fdatabase',['query_database',['../main_8cpp.html#a19243f49b1bf9b191cd49f2e0a19796b',1,'main.cpp']]]
];
