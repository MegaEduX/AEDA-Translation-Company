var searchData=
[
  ['texto',['Texto',['../class_texto.html',1,'']]],
  ['textoliterario',['TextoLiterario',['../class_texto_literario.html',1,'']]],
  ['textonoticioso',['TextoNoticioso',['../class_texto_noticioso.html',1,'']]],
  ['textotecnico',['TextoTecnico',['../class_texto_tecnico.html',1,'']]],
  ['tradutor',['Tradutor',['../class_tradutor.html',1,'']]]
];
