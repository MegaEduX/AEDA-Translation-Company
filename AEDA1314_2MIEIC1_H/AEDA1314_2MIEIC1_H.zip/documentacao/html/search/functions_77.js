var searchData=
[
  ['waitforreturn',['waitForReturn',['../namespace_additions.html#a05946b8c576a8237b5b447f70e55a79d',1,'Additions']]]
];
