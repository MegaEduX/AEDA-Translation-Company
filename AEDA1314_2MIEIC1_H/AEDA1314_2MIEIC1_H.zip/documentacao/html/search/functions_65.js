var searchData=
[
  ['edit_5frecord',['edit_record',['../main_8cpp.html#a246f7f8d4a33a1aed9e7030b5fb102c1',1,'main.cpp']]],
  ['edit_5frecord_5fstep2',['edit_record_step2',['../main_8cpp.html#a4791628b6e05e24fefc17e645eb6e42d',1,'main.cpp']]],
  ['edit_5frecord_5fstep3',['edit_record_step3',['../main_8cpp.html#a635942dacd803720a2b21b4ee18de727',1,'main.cpp']]],
  ['encomenda',['Encomenda',['../class_encomenda.html#acd872b2d444252423746ee7529b48ae8',1,'Encomenda::Encomenda(unsigned int id, Texto *texto, std::string lingua_destino, unsigned int duracao_max_dias)'],['../class_encomenda.html#a5009ce207f856836a16e93a6454e93b8',1,'Encomenda::Encomenda(unsigned int id, Texto *texto, std::string lingua_destino, unsigned int duracao_max_dias, Tradutor *tradutor, uint64_t timestamp_entrega)']]],
  ['explode',['explode',['../namespace_additions.html#a1abf6964ffd9abf97c743c514c2f401a',1,'Additions']]]
];
