var searchData=
[
  ['main',['main',['../main_8cpp.html#ac0f2228420376f4db7e1274f2b41667c',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['main_5fmenu',['main_menu',['../main_8cpp.html#a885611589f6294afada89fe88362e863',1,'main.cpp']]],
  ['manage_5fdatabase',['manage_database',['../main_8cpp.html#a4730f037ccb21250f146e3fa0a868b1c',1,'main.cpp']]]
];
