var searchData=
[
  ['podesatisfazerencomenda',['podeSatisfazerEncomenda',['../class_tradutor.html#a1d22a38c8eaa3753d44b521bb3aab2af',1,'Tradutor']]]
];
