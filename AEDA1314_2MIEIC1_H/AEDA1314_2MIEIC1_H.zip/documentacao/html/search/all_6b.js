var searchData=
[
  ['kclass',['kClass',['../_database_manager_8h.html#ad36b2b2507c9846942e0b412d07e5438',1,'DatabaseManager.h']]],
  ['kclassencomenda',['kClassEncomenda',['../_database_manager_8h.html#ad36b2b2507c9846942e0b412d07e5438a491a7f9f48558dbd59b5ee204c920bec',1,'DatabaseManager.h']]],
  ['kclasstexto',['kClassTexto',['../_database_manager_8h.html#ad36b2b2507c9846942e0b412d07e5438ad70eda5f7c0bfe5f9b94dcd06bc70ba1',1,'DatabaseManager.h']]],
  ['kclasstradutor',['kClassTradutor',['../_database_manager_8h.html#ad36b2b2507c9846942e0b412d07e5438a905951f6b0f883358810ecbd81358fae',1,'DatabaseManager.h']]],
  ['ktexto',['kTexto',['../_database_manager_8h.html#afe6eaf25f136cff817dad4241aeadedb',1,'DatabaseManager.h']]],
  ['ktextobase',['kTextoBase',['../_database_manager_8h.html#afe6eaf25f136cff817dad4241aeadedba601b6ebeb21416c7aa7e43fcd0c91564',1,'DatabaseManager.h']]],
  ['ktextoliterario',['kTextoLiterario',['../_database_manager_8h.html#afe6eaf25f136cff817dad4241aeadedbaa7596c6b206565d6f01ab2a2c60ba459',1,'DatabaseManager.h']]],
  ['ktextonoticioso',['kTextoNoticioso',['../_database_manager_8h.html#afe6eaf25f136cff817dad4241aeadedbad4c8b73ba2c61ae4e7480a3add76ecc2',1,'DatabaseManager.h']]],
  ['ktextotecnico',['kTextoTecnico',['../_database_manager_8h.html#afe6eaf25f136cff817dad4241aeadedba61858b836751767e8dfd6a03b44352a9',1,'DatabaseManager.h']]]
];
