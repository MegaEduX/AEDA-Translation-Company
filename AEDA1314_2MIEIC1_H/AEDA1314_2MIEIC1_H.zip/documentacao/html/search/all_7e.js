var searchData=
[
  ['_7edatabasemanager',['~DatabaseManager',['../class_database_manager.html#ae9b3a5da1e04fbb00faf8a034da1d063',1,'DatabaseManager']]]
];
