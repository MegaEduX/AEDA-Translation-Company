var searchData=
[
  ['init_5fdb',['init_db',['../_database_manager_8cpp.html#ad6f45b5277e7bb783bcfaed8f19388cb',1,'DatabaseManager.cpp']]]
];
