var searchData=
[
  ['texto_2ecpp',['Texto.cpp',['../_texto_8cpp.html',1,'']]],
  ['texto_2eh',['Texto.h',['../_texto_8h.html',1,'']]],
  ['textoliterario_2ecpp',['TextoLiterario.cpp',['../_texto_literario_8cpp.html',1,'']]],
  ['textoliterario_2eh',['TextoLiterario.h',['../_texto_literario_8h.html',1,'']]],
  ['textonoticioso_2ecpp',['TextoNoticioso.cpp',['../_texto_noticioso_8cpp.html',1,'']]],
  ['textonoticioso_2eh',['TextoNoticioso.h',['../_texto_noticioso_8h.html',1,'']]],
  ['textotecnico_2ecpp',['TextoTecnico.cpp',['../_texto_tecnico_8cpp.html',1,'']]],
  ['textotecnico_2eh',['TextoTecnico.h',['../_texto_tecnico_8h.html',1,'']]],
  ['tradutor_2ecpp',['Tradutor.cpp',['../_tradutor_8cpp.html',1,'']]],
  ['tradutor_2eh',['Tradutor.h',['../_tradutor_8h.html',1,'']]]
];
