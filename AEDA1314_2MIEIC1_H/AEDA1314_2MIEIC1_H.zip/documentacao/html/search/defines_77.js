var searchData=
[
  ['whitespace_5fendline_5fchars',['WHITESPACE_ENDLINE_CHARS',['../_texto_8cpp.html#af7f4f864ac8909a815f7d7968aff1b4f',1,'Texto.cpp']]]
];
