var searchData=
[
  ['kclass',['kClass',['../_database_manager_8h.html#ad36b2b2507c9846942e0b412d07e5438',1,'DatabaseManager.h']]],
  ['ktexto',['kTexto',['../_database_manager_8h.html#afe6eaf25f136cff817dad4241aeadedb',1,'DatabaseManager.h']]]
];
