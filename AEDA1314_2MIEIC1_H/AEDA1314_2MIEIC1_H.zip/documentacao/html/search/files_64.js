var searchData=
[
  ['databasemanager_2ecpp',['DatabaseManager.cpp',['../_database_manager_8cpp.html',1,'']]],
  ['databasemanager_2eh',['DatabaseManager.h',['../_database_manager_8h.html',1,'']]]
];
