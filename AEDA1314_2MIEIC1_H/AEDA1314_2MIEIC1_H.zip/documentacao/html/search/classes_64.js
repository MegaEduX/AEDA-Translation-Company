var searchData=
[
  ['databasemanager',['DatabaseManager',['../class_database_manager.html',1,'']]]
];
