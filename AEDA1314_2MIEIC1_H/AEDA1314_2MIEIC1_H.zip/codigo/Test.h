//
//  Test.h
//  translation_company
//
//  Created by Eduardo Almeida on 07/11/13.
//  Copyright (c) 2013 Bitten Apps. All rights reserved.
//

#ifndef translation_company_Test_h
#define translation_company_Test_h

void run_test_suite();

#endif
